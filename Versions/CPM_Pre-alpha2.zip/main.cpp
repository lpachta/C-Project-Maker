#include "cpm.h"

int main (int argc, char *argv[]) {
  Cpm cpm;
  cpm.loadOptions(argc, argv);
  return 0;
}
